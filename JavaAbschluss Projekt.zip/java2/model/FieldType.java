package model;

/**
 * Enumeration der verschiedenen Feldtypen im Labyrinth
 * Diese Typen bestimmen, wie jedes Feld im Spielfeld behandelt und dargestellt wird
 */
public enum FieldType {
    /** Wand-Feld: nicht begehbar für Spieler und Verfolger */
    WALL,
    /** Pfad-Feld: begehbar, normaler Weg im Labyrinth */
    PATH,
    /** Start-Feld: Position, an der der Spieler beginnt */
    START,
    /** Ziel-Feld: Position, die der Spieler erreichen muss, um zu gewinnen */
    GOAL
}
