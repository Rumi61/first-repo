package model;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Erzeugt ein Labyrinth als zweidimensionales Feld aus {@link FieldType}
 * Verwendet eine rekursive Backtracking-Methode zum den Pfad frei zumachen.
 */
public class MazeGenerator {

    private int width;
    private int height;
    private FieldType[][] maze;
    private Random random = new Random();

    /**
     * Konstruktor für MazeGenerator.
     * 
     * @param width Breite des Labyrinths
     * @param height Höhe des Labyrinths
     */
    public MazeGenerator(int width, int height) {
        this.width = width;
        this.height = height;
        this.maze = new FieldType[width][height];
    }

    /**
     * Generiert ein neues Labyrinth mit Start- und Zielposition.
     * 
     * @param start Position des Startfelds
     * @param goal Position des Zielfelds
     * @return Das generierte Labyrinth als 2D-Array von FieldType
     */
    public FieldType[][] generateMaze(Point start, Point goal) {
        // Initialisiere das gesamte Labyrinth mit Wänden
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                maze[i][j] = FieldType.WALL;
            }
        }

        // Beginne mit dem Pfadfreimachen an einer zufälligen Position
        int startX = random.nextInt(width);
        int startY = random.nextInt(height);
        carvePath(startX, startY);

        // Setze Start- und Zielposition explizit im Labyrinth
        maze[start.x][start.y] = FieldType.START;
        maze[goal.x][goal.y] = FieldType.GOAL;

        return maze;
    }

    /**
     * Rekursive Methode, die das Labyrinth frei maht
     * Sie durchläuft zufällige Richtungen und erzeugt Wege in 2er-Schritten
     * 
     * @param x Aktuelle x-Position
     * @param y Aktuelle y-Position
     */
    private void carvePath(int x, int y) {
        maze[x][y] = FieldType.PATH;

        // Erzeugt eine Liste mit allen Richtungen (NORD, SÜD, OST, WEST)
        List<Direction> directions = new ArrayList<>();
        for (Direction d : Direction.values()) {
            directions.add(d);
        }
        // Mischt die Reihenfolge der Richtungen, um zufällige Pfade zu erzeugen
        Collections.shuffle(directions);

        // Versuche in jede Richtung zwei Felder weit zu gehen
        for (Direction dir : directions) {
            int newX = x + dir.deltaX * 2;
            int newY = y + dir.deltaY * 2;

            // Prüfe, ob das neue Feld innerhalb des Labyrinths liegt
            if (isValid(newX, newY)) {
                // Wenn das Ziel noch eine Wand ist, schaufle den Weg frei
                if (maze[newX][newY] == FieldType.WALL) {
                    // Das Feld zwischen aktueller Position und neuem Feld wird zum Pfad
                    maze[x + dir.deltaX][y + dir.deltaY] = FieldType.PATH;
                    // Rekursiver Aufruf für das neue Feld
                    carvePath(newX, newY);
                }
            }
        }
    }

    /**
     * Prüft, ob eine Position innerhalb des Labyrinths liegt.
     * 
     * @param x x-Koordinate
     * @param y y-Koordinate
     * @return true, wenn Position gültig ist, sonst false
     */
    private boolean isValid(int x, int y) {
        return x >= 0 && x < width && y >= 0 && y < height;
    }
}
