package model;

import java.awt.Point;
import java.util.Random;

/**
 * Repräsentiert einen Verfolger im Labyrinth, der den Spieler verfolgt.
 * Der Verfolger bewegt sich jeweils einen Schritt in Richtung Spieler,
 * wobei er versucht, sich auf begehbaren Feldern zu bewegen.
 */
public class Follower {
    /** Aktuelle Position des Verfolgers im Labyrinth */
    private Point position;

    /**
     * Erstellt einen neuen Verfolger an der angegebenen Startposition.
     * 
     * @param startPosition Die Anfangsposition des Verfolgers.
     */
    public Follower(Point startPosition) {
        this.position = startPosition;
    }

    /**
     * Gibt die aktuelle Position des Verfolgers zurück.
     * 
     * @return Position als Point-Objekt.
     */
    public Point getPosition() {
        return position;
    }

    /**
     * Bewegt den Verfolger einen Schritt in Richtung des Spielers.
     * Dabei wird zufällig entschieden, ob zuerst horizontal oder vertikal bewegt wird.
     * Bewegung erfolgt nur auf begehbaren Feldern (kein WALL).
     * 
     * @param playerPos Die aktuelle Position des Spielers.
     * @param maze Das Spielfeld als 2D-Array mit Feldtypen.
     */
    public void moveTowards(Point playerPos, FieldType[][] maze) {
        // Bestimme Bewegungsrichtung auf x- und y-Achse (-1, 0 oder 1)
        int dx = Integer.compare(playerPos.x, position.x);
        int dy = Integer.compare(playerPos.y, position.y);

        // Zufällig entscheiden, ob horizontal oder vertikal zuerst versucht wird
        boolean tryXFirst = new Random().nextBoolean();
        Point newPos = new Point(position);

        if (tryXFirst) {
            // Versuch, horizontal zu bewegen, falls möglich
            if (isWalkable(position.x + dx, position.y, maze)) {
                newPos.translate(dx, 0);
            }
            // Sonst vertikal bewegen, falls möglich
            else if (isWalkable(position.x, position.y + dy, maze)) {
                newPos.translate(0, dy);
            }
        } else {
            // Versuch, vertikal zu bewegen, falls möglich
            if (isWalkable(position.x, position.y + dy, maze)) {
                newPos.translate(0, dy);
            }
            // Sonst horizontal bewegen, falls möglich
            else if (isWalkable(position.x + dx, position.y, maze)) {
                newPos.translate(dx, 0);
            }
        }

        // Aktualisiere die Position des Verfolgers
        position = newPos;
    }

    /**
     * Prüft, ob ein Feld begehbar ist (innerhalb des Spielfelds und kein WALL).
     * 
     * @param x x-Koordinate im Spielfeld
     * @param y y-Koordinate im Spielfeld
     * @param maze Das Spielfeld als 2D-Array mit Feldtypen
     * @return true, wenn das Feld begehbar ist, sonst false.
     */
    private boolean isWalkable(int x, int y, FieldType[][] maze) {
        return x >= 0 && y >= 0 && x < maze.length && y < maze[0].length
            && maze[x][y] != FieldType.WALL;
    }
}
