package model;

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import view.View;

/**
 * The world is our model. It saves the bare minimum of information required to
 * accurately reflect the state of the game. Note how this does not know
 * anything about graphics.
 */
public class World {

    /** The world's width. */
    private final int width;
    /** The world's height. */
    private final int height;
    /** The player's x position in the world. */
    private int playerX = 0;
    /** The player's y position in the world. */
    private int playerY = 0;

    /** Das Spielfeld (Labyrinth) mit Feldertypen */
    private FieldType[][] maze;

    /** Position des Startfelds */
    private Point startPosition;
    /** Position des Zielfelds */
    private Point goalPosition;

    /** Set of views registered to be notified of world updates. */
    private final ArrayList<View> views = new ArrayList<>();

    /** Liste der Verfolger */
    private final List<Point> followers = new ArrayList<>();
    private final Random random = new Random();

    /** Creates a new world with given size. */
    public World(int width, int height) {
        // Normally, we would check the arguments for proper values
        this.width = width;
        this.height = height;
        this.maze = new FieldType[width][height];

        MazeGenerator generator = new MazeGenerator(width, height);

        // Zufällige Start- und Zielposition erzeugen
        int startX, startY, goalX, goalY;
        do {
            startX = random.nextInt(width);
            startY = random.nextInt(height);
            goalX = random.nextInt(width);
            goalY = random.nextInt(height);
        } while ((startX == goalX && startY == goalY) || (startX % 2 != 1 || startY % 2 != 1) || (goalX % 2 != 1 || goalY % 2 != 1));

        this.startPosition = new Point(startX, startY);
        this.goalPosition = new Point(goalX, goalY);

        // Labyrinth generieren
        this.maze = generator.generateMaze(startPosition, goalPosition);

        // Spieler auf Startposition setzen
        setPlayerX(startPosition.x);
        setPlayerY(startPosition.y);

        // Anzahl der Follower zufällig zwischen 1 und 3
        int followerCount = 1 + random.nextInt(3);
        generateFollowers(followerCount);
    }

    // Follower erzeugen an zufälligen gültigen Positionen (keine Wände, nicht Start/Ziel)
    private void generateFollowers(int count) {
        followers.clear();
        while (followers.size() < count) {
            int x = random.nextInt(width);
            int y = random.nextInt(height);

            if (maze[x][y] != FieldType.WALL && !(x == playerX && y == playerY) && !(x == goalPosition.x && y == goalPosition.y)) {
                Point p = new Point(x, y);
                if (!followers.contains(p)) {
                    followers.add(p);
                }
            }
        }
    }

    /** Gibt eine Kopie der aktuellen Follower-Liste zurück */
    public List<Point> getFollowers() {
        return List.copyOf(followers);
    }

    ///////////////////////////////////////////////////////////////////////////
    // Getters and Setters

    /**
     * Returns the width of the world.
     * 
     * @return the width of the world.
     */
    public int getWidth() { return width; }

    /**
     * Returns the height of the world.
     * 
     * @return the height of the world.
     */
    public int getHeight() { return height; }

    /**
     * Returns the player's x position.
     * 
     * @return the player's x position.
     */
    public int getPlayerX() { return playerX; }

    /**
     * Sets the player's x position and updates the views.
     * 
     * @param x the player's new x position.
     */
    public void setPlayerX(int x) {
        playerX = Math.max(0, Math.min(width -1, x));
        updateViews();
    }

    /**
     * Returns the player's y position.
     * 
     * @return the player's y position.
     */
    public int getPlayerY() { return playerY; }

    /**
     * Sets the player's y position and updates the views.
     * 
     * @param y the player's new y position.
     */
    public void setPlayerY(int y) {
        playerY = Math.max(0, Math.min(height -1, y));
        updateViews();
    }
    

    /**
     * Gibt das komplette Labyrinth-Feld zurück
     */
    public FieldType[][] getMaze() { return maze; }

    /**
     * Gibt den Typ des Feldes an gegebener Position zurück
     */
    public FieldType getFieldType(int x, int y) {
        if (x < 0 || x >= width || y < 0 || y >= height) return null;
        return maze[x][y];
    }

    /**
     * Gibt die Startposition zurück.
     */
    public Point getStartPosition() { return startPosition; }

    /**
     * Gibt die Zielposition zurück.
     */
    public Point getGoalPosition() { return goalPosition; }



    ///////////////////////////////////////////////////////////////////////////
    // Player Management

    /**
     * Moves the player along the given direction.
     * 
     * @param direction where to move.
     */
    public void movePlayer(Direction direction) {
        int newPlayerX = getPlayerX() + direction.deltaX;
        int newPlayerY = getPlayerY() + direction.deltaY;

        // Prüfe, ob neues Feld gültig und kein Hindernis ist
        if (newPlayerX >= 0 && newPlayerX < width &&
            newPlayerY >= 0 && newPlayerY < height &&
            maze[newPlayerX][newPlayerY] != FieldType.WALL) {

            // Spielerposition aktualisieren
            setPlayerX(newPlayerX);
            setPlayerY(newPlayerY);

            // Verfolger bewegen sich nach dem Spieler
            moveFollowers();

            // Prüfen, ob Ziel erreicht
            if (newPlayerX == goalPosition.x && newPlayerY == goalPosition.y) {
                javax.swing.SwingUtilities.invokeLater(() -> {
                    javax.swing.JOptionPane.showMessageDialog(null,
                        "Du hast das Ziel erreicht!",
                        "Gewonnen",
                        javax.swing.JOptionPane.INFORMATION_MESSAGE);
                    resetGame();
                    updateViews();
                });
            }

            // Prüfen, ob Spieler von einem Verfolger gefangen wurde
            for (Point f : followers) {
                if (f.x == playerX && f.y == playerY) {
                    javax.swing.SwingUtilities.invokeLater(() -> {
                        javax.swing.JOptionPane.showMessageDialog(null,
                            "Du wurdest von einem Verfolger gefangen!",
                            "Verloren",
                            javax.swing.JOptionPane.WARNING_MESSAGE);
                        resetGame();
                        updateViews();
                    });
                    break;
                }
            }
        }
    }

    // Verfolger bewegen sich einen Schritt in Richtung Spieler
    private void moveFollowers() {
        List<Point> newPositions = new ArrayList<>();

        for (Point follower : followers) {
            int dx = playerX - follower.x;
            int dy = playerY - follower.y;

            int stepX = Integer.compare(dx, 0); // -1, 0 oder 1
            int stepY = Integer.compare(dy, 0);

            Point newPosX = new Point(follower.x + stepX, follower.y);
            Point newPosY = new Point(follower.x, follower.y + stepY);
            Point newPos = follower;

            if (stepX != 0 && isValidMove(newPosX, newPositions)) {
                newPos = newPosX;
            } else if (stepY != 0 && isValidMove(newPosY, newPositions)) {
                newPos = newPosY;
            }

            newPositions.add(newPos);
        }

        followers.clear();
        followers.addAll(newPositions);
    }

    // Prüft, ob ein Feld gültig ist (innerhalb, kein Hindernis, kein Überschneiden)
    private boolean isValidMove(Point pos, List<Point> occupied) {
        if (pos.x < 0 || pos.x >= width || pos.y < 0 || pos.y >= height) return false;
        if (maze[pos.x][pos.y] == FieldType.WALL) return false;
        if (pos.x == playerX && pos.y == playerY) return false;
        if (occupied.contains(pos)) return false;
        return true;
    }

    ///////////////////////////////////////////////////////////////////////////
    // View Management

    /**
     * Adds the given view of the world and updates it once. Once registered through
     * this method, the view will receive updates whenever the world changes.
     * 
     * @param view the view to be registered.
     */
    public void registerView(View v) {
        views.add(v);
        v.update(this);
    }

    /**
     * Updates all views by calling their {@link View#update(World)} methods.
     */
    private void updateViews() {
        for (View v : views) v.update(this);
    }

    /**
     * Setzt das Spiel zurück: neues Labyrinth, neue Positionen, neue Follower.
     */
    public void resetGame() {
        MazeGenerator generator = new MazeGenerator(width, height);

        int startX, startY, goalX, goalY;
        do {
            startX = random.nextInt(width);
            startY = random.nextInt(height);
            goalX = random.nextInt(width);
            goalY = random.nextInt(height);
        } while ((startX == goalX && startY == goalY) || (startX % 2 != 1 || startY % 2 != 1) || (goalX % 2 != 1 || goalY % 2 != 1));

        this.startPosition = new Point(startX, startY);
        this.goalPosition = new Point(goalX, goalY);
        this.maze = generator.generateMaze(startPosition, goalPosition);

        setPlayerX(startX);
        setPlayerY(startY);

        // Anzahl der Follower zufällig zwischen 1 und 3
        int followerCount = 1 + random.nextInt(3);
        generateFollowers(followerCount);

        updateViews();
    }
}
