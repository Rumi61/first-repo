package view;

import java.awt.Point;
import java.util.List;
import model.FieldType;
import model.World;

/**
 * A view that prints the current state of the world to the console upon every
 * update.
 */
public class ConsoleView implements View {

    @Override
    public void update(World world) {
        // The player's position
        int playerX = world.getPlayerX(); // Spieler-X-Position abrufen
        int playerY = world.getPlayerY(); // Spieler-Y-Position abrufen
        List<Point> followers = world.getFollowers(); // Liste der Verfolger abrufen

        // Zeilenweise Durchlauf durch das Spielfeld
        for (int row = 0; row < world.getHeight(); row++) {
            for (int col = 0; col < world.getWidth(); col++) {

                // Prüfen, ob sich ein Verfolger an dieser Position befindet
                boolean isFollowerHere = false;
                for (Point f : followers) {
                    if (f.x == col && f.y == row) {
                        isFollowerHere = true;
                        break;
                    }
                }

                // Prüfen, was an dieser Position angezeigt werden soll
                if (row == playerY && col == playerX) {
                    System.out.print("P "); // Player
                } else if (isFollowerHere) {
                    System.out.print("F "); // Follower
                } else {
                    FieldType fieldType = world.getFieldType(col, row);
                    switch (fieldType) {
                        case WALL:
                            System.out.print("# "); // Wall
                            break;
                        case PATH:
                            System.out.print(". "); // Path
                            break;
                        case START:
                            System.out.print("S "); // Start
                            break;
                        case GOAL:
                            System.out.print("G "); // Goal
                            break;
                    }
                }
            }
            // A newline after every row
            System.out.println(); // Neue Zeile nach jeder Zeile der Welt
        }
        // A newline after every update
        System.out.println(); // Leere Zeile nach jeder Weltaktualisierung
    }
}
