package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import javax.swing.JPanel;
import model.FieldType;
import model.World;

public class GraphicView extends JPanel implements View {

    private final int WIDTH;
    private final int HEIGHT;

    private Dimension fieldDimension;

    public GraphicView(int width, int height, Dimension fieldDimension) {
        this.WIDTH = width;
        this.HEIGHT = height;
        this.fieldDimension = fieldDimension;
        this.bg = new Rectangle(WIDTH, HEIGHT);
    }

    private final Rectangle bg;
    private final Rectangle player = new Rectangle(1, 1);

    private World currentWorld;

    /**
     * Creates a new instance.
     */

    @Override
    public void paint(Graphics g) {
        // Hintergrund hellgrau
        g.setColor(Color.LIGHT_GRAY);
        g.fillRect(bg.x, bg.y, bg.width, bg.height);

if (currentWorld != null) {
    // Zeichne das Labyrinth-Feld für jede Zelle im Spielfeld
    for (int y = 0; y < currentWorld.getHeight(); y++) {
        for (int x = 0; x < currentWorld.getWidth(); x++) {
            FieldType fieldType = currentWorld.getFieldType(x, y);

            // Wähle die Farbe entsprechend dem Feldtyp
            switch (fieldType) {
                case WALL -> g.setColor(Color.WHITE); // Mauer
                case PATH -> g.setColor(new Color(255, 220, 235)); // Begehbarer Weg (rosa)
                case START -> g.setColor(Color.GREEN); // Startpunkt
                case GOAL -> g.setColor(Color.RED); // Zielpunkt
            }

            // Berechne die Zeichenposition in Pixeln
            int drawX = x * fieldDimension.width;
            int drawY = y * fieldDimension.height;

            // Fülle das Feld mit der gewählten Farbe
            g.fillRect(drawX, drawY, fieldDimension.width, fieldDimension.height);

            // Zeichne die Feldumrandung in schwarz
            g.setColor(Color.BLACK);
            g.drawRect(drawX, drawY, fieldDimension.width, fieldDimension.height);
        }
    }

            // Paint follower (blue)
            g.setColor(Color.BLUE);
            for (var follower : currentWorld.getFollowers()) {
                int fx = follower.x * fieldDimension.width;
                int fy = follower.y * fieldDimension.height;
                g.fillRect(fx, fy, fieldDimension.width, fieldDimension.height);
            }

            // Paint player pink
            g.setColor(new Color(255, 20, 147));
            g.fillRect(player.x, player.y, player.width, player.height);
        }
    }

    @Override
    public void update(World world) {
        // Update players siza and location
        this.currentWorld = world;
        player.setSize(fieldDimension);
        player.setLocation(
            world.getPlayerX() * fieldDimension.width,
            world.getPlayerY() * fieldDimension.height
        );
        repaint();
    }
}
