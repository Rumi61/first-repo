/**
 * Ist eine Unterklasse von Contact
 * Repräsentiert einen Firmenkontakt mit Firmenname, Name des Inhabers und Adresse
 */
public class FirmenContakt extends Contact {
    private String firmenname;

    /**
     * Konstruktor für die Klasse FirmenContakt.
     *
     * @param firmenname der Name der Firma
     * @param besitzervorname   der Name des Inhabers
     * @param adresse    die Adresse des Kontakts
     * @param besitzernachname    der Nachname des Inhabers
     */

    public FirmenContakt(String firmenname, Name besitzername, Adress adresse) {
        super(besitzername, adresse); // Besitzer ist der "Name" aus der Oberklasse
        this.firmenname = firmenname;
    }

    public String getFirmenname() {
        return firmenname;
    }
    @Override
    public String toString() {
        return  "Firmenkontakt: " + firmenname +
                ", Sitz: " + getAdresse().toString() +
                ", Inhaber: " + getName().toString();
    }
}
