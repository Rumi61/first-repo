/**
 * Abstrakte Oberklasse für verschiedene Arten von Kontakten.
 * Alle Kontakte enthalten Name und Adresse
 */
public abstract class Contact{
    private Name name;
    private Adress adresse;
    
/**
 * Konstruktor für die Klasse Contact.
 *
 * @param name    der Name des Kontakts
 * @param adresse die Adresse des Kontakts
 */

public Contact(Name name, Adress adresse) {
        this.name = name ;
        this.adresse = adresse;
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }

    public Adress getAdresse() {
        return adresse;
    }

    public void setAdresse(Adress adresse) {
        this.adresse = adresse;
    }
    
    
    public String toString(){
        return name + ", " + adresse;
    }

    public static void main(String[] args) {
    Name name = new Name("Sören", "Domrös");
    Adress adresse = new Adress("Christian-Albrechst-Platz", 24118, "Kiel", 4);
    Contact contact = new FirmenContakt ("SDO Unlimited",name, adresse);
    System.out.println(contact);
    }

}
