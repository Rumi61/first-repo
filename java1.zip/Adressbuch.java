import java.util.ArrayList;
import java.util.Scanner;

/**
 * Adressbuch-Klasse zur Verwaltung von Kontakten.
 * Diese Klasse ermöglicht das Hinzufügen, Löschen und Suchen von Kontakten.
 */
public class Adressbuch{
    private ArrayList<Contact> contact = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    /**
     * Fügt einen neuen Kontakt zum Adressbuch hinzu.
     * Der Benutzer wird aufgefordert, die Details des Kontakts einzugeben.
     */

    public void addcontact(){
        System.out.println("Person hinzufügen:1 oder Firma hinzufügen:2");
        int num = Integer.parseInt(scanner.nextLine());

        if(num ==1){
        System.out.println("Bitte geben Sie den Vornamen ein:");
        String vorname = scanner.nextLine();

        System.out.println("Bitte geben Sie den Nachnamen ein:");
        String nachname = scanner.nextLine();

        System.out.println("Bitte geben Sie die Adresse ein:");
        String adresse = scanner.nextLine();

        System.out.println("Bitte geben Sie die PLZ ein:");
        int plz = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Bitte geben Sie die Stadt ein:");
        String stadt = scanner.next();

        System.out.println("Bitte geben Sie die Hausnummer ein:");
        int hausnummer = scanner.nextInt();
        scanner.nextLine();

        Name name = new Name(vorname, nachname);
        Adress adress = new Adress(adresse, plz, stadt, hausnummer);
        Contact newContact = new PrivateContact(name, adress);
        contact.add(newContact);
        System.out.print("Kontakt wurde hinzugefügt: " + newContact);
    }
    /**
     * Falls 2 gewählt wird, werden die Firmadaten abgefragt
     */
        else if(num ==2){
        System.out.println("Bitte geben Sie den Firmennamen ein:");
        String firmenname = scanner.nextLine();

        System.out.println("Bitte geben Sie den Vornamen des Besitzers ein:");
        String besitzervorname = scanner.nextLine();

        System.out.println("Bitte geben Sie den Nachnamen des Besitzers ein:");
        String besitzernachname = scanner.nextLine();

        System.out.println("Bitte geben Sie die Adresse ein:");
        String adresse = scanner.nextLine();

        System.out.println("Bitte geben Sie die PLZ ein:");
        int plz = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Bitte geben Sie die Stadt ein:");
        String stadt = scanner.next();

        System.out.println("Bitte geben Sie die Hausnummer ein:");
        int hausnummer = scanner.nextInt();
        scanner.nextLine();

        Name besitzername = new Name(besitzervorname, besitzernachname);
        Adress adress = new Adress(adresse, plz, stadt, hausnummer);
        Contact newContact = new PrivateContact(besitzername, adress);
        contact.add(newContact);
        System.out.print("Kontakt wurde hinzugefügt: " );
    }
    }

    /**
     * Löscht einen Kontakt aus dem Adressbuch.
     * Der Benutzer wird aufgefordert, die Nummer des zu löschenden Kontakts einzugeben.
     * Wenn die Nummer ungültig ist, wird eine entsprechende Nachricht angezeigt.
     */
    public void deleteContact(){
        printContacts();
        if (contact.isEmpty()) {
            System.out.println("Das Adressbuch ist leer.");
            return;
        }
        System.out.println("Bitte geben Sie die Nummer des zu löschenden Kontakts ein:");
        int index = scanner.nextInt();
        scanner.nextLine();

        if (index >= 0 && index < contact.size()) {
            Contact removeContact = contact.remove(index);
            System.out.println("Kontakt wurde gelöscht: " + removeContact);
        } else {
            System.out.println("Ungültige Nummer. Kein Kontakt gelöscht.");
        }
    }
    /**
     * Gibt alle Kontakte im Adressbuch aus.
     * Wenn das Adressbuch leer ist, wird eine entsprechende Nachricht angezeigt.
     */
    public void printContacts() {
        if (contact.isEmpty()) {
            System.out.println("Adressbuch ist leer.");
        } else {
            for (int i = 0; i < contact.size(); i++) {
                System.out.println("[" + i + "] " + contact.get(i));
            }
        }
    }
    /**
     * Sucht nach Kontakten im Adressbuch, die den angegebenen Suchbegriff enthalten.
     * Gibt alle gefundenen Kontakte aus oder eine Nachricht, wenn keine gefunden wurden.
     */
    public void search(String s) {
        boolean gefunden = false;
        for (Contact c : contact) {
            if (c.toString().toLowerCase().contains(s.toLowerCase())) {
                System.out.println(c);
                //System.out.println();
                gefunden = true;
            }
        }
        if (!gefunden) {
            System.out.println("Kein Kontakt gefunden.");
        }
    }

}