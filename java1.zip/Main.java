
import java.util.Scanner;


/**
 * Programm wird durch die Main Klasse gestartet
 * Kontakte werden hinzugefüht, gesucht,gelöscht und ausgegeben
 */
public class Main {
    public static void main(String[] args) {
        Adressbuch buch = new Adressbuch();
        buch.addcontact();
        buch.printContacts();
        System.out.println("Suche nach Kontakt:");
        Scanner scanner = new Scanner(System.in);
        String searchterm = scanner.nextLine();
        //buch.search("Christian-Albrechts-Platz");
        buch.search(searchterm);
        buch.deleteContact();

    }

}
