/**
 * Repräsentiert eine Adresse mit Straße, Postleitzahl, Stadt und Hausnummer.
 */
public class Adress{
    private String strasse;
    private int plz;
    private String stadt;
    private int hausnummer;

    /**
     * Konstruktor für die Klasse Adress.
     *
     * @param strasse   die Straße der Adresse
     * @param plz       die Postleitzahl der Adresse
     * @param stadt     die Stadt der Adresse
     * @param hausnummer die Hausnummer der Adresse
     */
    
    public Adress(String strasse, int plz, String stadt,int hausnummer) {
        this.strasse = strasse;
        this.plz = plz;
        this.stadt = stadt;
        this.hausnummer = hausnummer;
    }

    public String getStrasse() {
        return strasse;
    }

    private void setStrasse(String strasse) {
        this.strasse = strasse;
    }

    public int getPlz() {
        return plz;
    }

    private void setPlz (int plz) {
        this.plz = plz;
    }

    public String getStadt() {
        return stadt;
    }

    private void setStadt(String stadt) {
        this.stadt = stadt;
    }

    public int getHausnummer() {
        return hausnummer;
    }
    private void setHausnummer(int hausnummer) {
        this.hausnummer = hausnummer;
    }
    public String toString() {
        return plz + " "+ stadt + ", " + strasse + " " + hausnummer;
    }
    public static void main(String[] args) {
        Adress adresse = new Adress("Annenstraße", 24782, "Kiel",1);
        System.out.println(adresse.toString());
    }
}

