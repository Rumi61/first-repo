/**
 * Darstellung eines privaten Kontakts(Vorname, Nachname, Adresse)
 * Ist eine Unterklasse von Contact
 */
public class PrivateContact extends Contact {
    public PrivateContact(Name name, Adress adresse) {
        super(name, adresse);
    }
}

